from django.apps import AppConfig


class AyomidescrumyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ayomidescrumy'
