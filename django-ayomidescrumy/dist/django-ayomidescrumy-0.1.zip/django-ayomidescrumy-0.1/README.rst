====
ayomidescrumy
====

Ayomidescrumy is a simple Django app that returns "Welcome to Django"